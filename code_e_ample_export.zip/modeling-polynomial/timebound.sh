#!/bin/sh

datafile="script2.sh.o10547"

gnuplot << EOF

set terminal pdf
set output 'time.pdf'

set xlabel 'n'
set ylabel 'd'
set zlabel 'time (in seconds)'
	
set xrange [1:100000]
set yrange [1:100000]

set logscale

splot 3*x*(1+y)/(1.7*1000*1000*1000*1000) t 'Flop bound', \
      (2*x+y+1)*4/(100*1000*1000*1000) t 'Memory BW bound' lc 3


set output 'performance.pdf'

set xlabel 'n'
set ylabel 'd'
set zlabel 'Performance (in coef/s)'
	
set xrange [1:100000]
set yrange [1:100000]

set logscale x
set logscale y

splot (x*y)/(3*x*(1+y)/(1.7*1000*1000*1000*1000)) t 'Flop bound', \
      (x*y)/((2*x+y+1)*4/(100*1000*1000*1000)) t 'Memory BW bound' lc 3


set output 'measured.pdf'

set xlabel 'n'
set ylabel 'd'
set zlabel 'Performance (in coef/s)'
	
set xrange [1:268435456]
set yrange [1:1000]

set logscale x
set logscale y

splot (x*y)/(3*x*(1+y)/(1.7*1000*1000*1000*1000)) t 'Flop bound', \
      (x*y)/((2*x+y+1)*4/(100*1000*1000*1000)) t 'Memory BW bound' lc 3, \
      '${datafile}' u 1:2:(\$1*\$2/\$3) t 'basic code'

EOF


plot_x_proj() {
    y=$1

    awk "{if (\$2 == ${y}){ print \$0}}" < ${datafile} > data_y_${y}

    gnuplot<<EOF

set terminal pdf
set output 'measured_y_${y}.pdf'

set xlabel 'n'
set ylabel 'Performance (in coef/s)'
	
set key top left

set title 'd = ${y}'

set logscale x
set logscale y

plot (x*${y})/(3*x*(1+${y})/(1.7*1000*1000*1000*1000)) t 'Flop bound', \
      (x*${y})/((2*x+${y}+1)*4/(100*1000*1000*1000)) t 'Memory BW bound' lc 3, \
      'data_y_${y}' u 1:(\$1*\$2/\$3) t 'basic code'


EOF
}

plot_y_proj() {
    x=$1

    awk "{if (\$1 == ${x}){ print \$0}}" < ${datafile} > data_x_${x}

    gnuplot<<EOF

set terminal pdf
set output 'measured_x_${x}.pdf'

set xlabel 'd'
set ylabel 'Performance (in coef/s)'
	
set key top left

set title 'n = ${x}'

set logscale x
set logscale y

plot (${x}*x)/(3*${x}*(1+x)/(1.7*1000*1000*1000*1000)) t 'Flop bound', \
      (${x}*x)/((2*${x}+x+1)*4/(100*1000*1000*1000)) t 'Memory BW bound' lc 3, \
      'data_x_${x}' u 2:(\$1*\$2/\$3) t 'basic code'


EOF
}


plot_x_proj 4
plot_x_proj 20
plot_x_proj 50
plot_x_proj 100

plot_y_proj 16384
plot_y_proj 67108864
